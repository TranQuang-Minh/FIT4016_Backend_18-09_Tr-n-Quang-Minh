using System;

namespace StudentGradesApp
{
    class StudentGrades
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap diem: ");
            int score = int.Parse(Console.ReadLine());

            if (score >= 90 && score <= 100)
            {
                Console.WriteLine("Xep loai: A - Xuat sac");
            }
            else if (score >= 80)
            {
                Console.WriteLine("Xep loai: B - Kha");
            }
            else if (score >= 70)
            {
                Console.WriteLine("Xep loai: C - Trung binh");
            }
            else if (score >= 50)
            {
                Console.WriteLine("Xep loai: D - Yeu");
            }
            else
            {
                Console.WriteLine("Xep loai: F - Dot");
            }
        }
    }
}

/*
GIAI THICH:
- Nhap diem sinh vien tu ban phim.
- Dung if - else if - else de xep loai.
- Minh hoa cau truc re nhanh nhieu dieu kien.
*/
