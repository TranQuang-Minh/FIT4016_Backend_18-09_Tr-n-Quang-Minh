using System;

namespace BasicMethods
{
    class Program
    {
        // Phương thức Add dùng để tính tổng của hai số nguyên
        // a: số nguyên thứ nhất
        // b: số nguyên thứ hai
        // Giá trị trả về là tổng của a và b
        static int Add(int a, int b)
        {
            return a + b;
        }

        // Phương thức Multiply dùng để tính tích của hai số thực
        // x: số thực thứ nhất
        // y: số thực thứ hai
        // Giá trị trả về là tích của x và y
        static double Multiply(double x, double y)
        {
            return x * y;
        }

        static void Main(string[] args)
        {
            // Gọi phương thức Add để tính tổng 5 + 3
            int sum = Add(5, 3);

            // In kết quả tổng ra màn hình
            Console.WriteLine("Tong = " + sum);

            // Gọi phương thức Multiply để tính tích 2.5 * 4
            double product = Multiply(2.5, 4);

            // In kết quả tích ra màn hình
            Console.WriteLine("Tich = " + product);
        }
    }
}
