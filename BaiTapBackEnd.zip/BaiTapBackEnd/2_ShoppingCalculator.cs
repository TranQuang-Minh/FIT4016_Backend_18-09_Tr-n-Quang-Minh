using System;

namespace ShoppingCalculatorApp
{
    class ShoppingCalculator
    {
        static void Main(string[] args)
        {
            // Khai bao gia tien va so luong
            double price = 15000;   // gia 1 san pham
            int quantity = 3;       // so luong mua

            // Tinh tong tien
            double total = price * quantity;

            // Neu tong tien > 40000 thi giam 10%
            if (total > 40000)
            {
                total = total * 0.9;
            }

            Console.WriteLine("Tong tien can thanh toan: " + total);
        }
    }
}

/*
Giari thích :
- Chuong trinh tinh tong tien mua hang.
- double dung cho gia tien, int dung cho so luong.
- if dung de kiem tra dieu kien giam gia.
*/
