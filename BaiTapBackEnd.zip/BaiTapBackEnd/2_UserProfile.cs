using System;

namespace UserProfileApp
{
    class UserProfile
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap ten: ");
            string name = Console.ReadLine();

            Console.Write("Nhap tuoi: ");
            int age = int.Parse(Console.ReadLine());

            Console.WriteLine("Thong tin nguoi dung:");
            Console.WriteLine("Ten: " + name);
            Console.WriteLine("Tuoi: " + age);
        }
    }
}

/*
GIAI THICH:
- Nhap thong tin nguoi dung (ten, tuoi).
- Su dung string va int.
- Console.ReadLine() de nhap du lieu.
*/
