using System;
namespace DayOfWeekSwitch
{
    class Program
    {
        static void Main(string[] args)
        {
            // Khai báo biến day để lưu số đại diện cho ngày trong tuần (1-7)
            int day = 3; // 3 tương ứng với Thứ Tư

            // Sử dụng switch để xác định tên ngày dựa vào giá trị của day
            switch (day)
            {
                case 1:
                    // Trường hợp day = 1
                    Console.WriteLine("Thu Hai");
                    break;
                case 2:
                    // Trường hợp day = 2
                    Console.WriteLine("Thu Ba");
                    break;
                case 3:
                    // Trường hợp day = 3
                    Console.WriteLine("Thu Tu");
                    break;
                case 4:
                    // Trường hợp day = 4
                    Console.WriteLine("Thu Nam");
                    break;
                case 5:
                    // Trường hợp day = 5
                    Console.WriteLine("Thu Sau");
                    break;
                case 6:
                    // Trường hợp day = 6
                    Console.WriteLine("Thu Bay");
                    break;
                case 7:
                    // Trường hợp day = 7
                    Console.WriteLine("Chu Nhat");
                    break;
                default:
                    // Trường hợp nhập số không hợp lệ (không nằm trong 1-7)
                    Console.WriteLine("Ngay khong hop le");
                    break;
            }
        }
    }
}
